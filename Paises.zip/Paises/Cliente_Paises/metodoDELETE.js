const API_URL = 'http://localhost/PaisesAfectados/PaisesService.php';
function eliminar(){
    var vID = document.getElementById("ID").value;

}